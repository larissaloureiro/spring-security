package br.com.dh.brecho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrechoApplicationTests {

	@Test
	void contextLoads() {
	}

}
