package br.com.dh.brecho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrechoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrechoApplication.class, args);
	}

}
